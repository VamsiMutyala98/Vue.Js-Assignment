<template>
    <div class="div" style="padding-top:48%;text-align:center;postion:sticky">
        <h5>@copyright: Qproducts.Inc or its afflicates. Since 2021</h5>
    </div>
</template>
<script>
export default {
    name: 'Footer',
}
</script>
<style scoped>
.div{

}
</style>